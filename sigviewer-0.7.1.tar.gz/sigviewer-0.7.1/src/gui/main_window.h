// © SigViewer developers
//
// License: GPL-3.0


#ifndef MAIN_WINDOW_H
#define MAIN_WINDOW_H

#include "application_context.h"

#include <QMainWindow>
#include <QProgressBar>

class QAction;
class QComboBox;
class QMenu;
class QLabel;
class QToolButton;

namespace sigviewer
{

// main window
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow (QSharedPointer<ApplicationContext> application_context);
    virtual ~MainWindow () {}

    void setStatusBarSignalLength(float64 length);
    void setStatusBarNrChannels(int32 nr_channels);
    void setOverviewActionEnabled(bool enabled);

    void setRecentFiles(const QStringList& recent_file_list);

signals:
    void recentFileActivated(QAction* recent_file_action);
    void recentFileMenuAboutToShow();
    void overviewVisibilityChanged(bool visible);


protected:
    virtual void closeEvent(QCloseEvent* close_event);
    virtual void dropEvent (QDropEvent* event);
    virtual void dragEnterEvent(QDragEnterEvent *event);
    virtual void resizeEvent (QResizeEvent* event);
    virtual void changeEvent(QEvent* event);
private slots:
    void toggleStatusBar (bool visible);
    void toggleMenuBar ();
    void toggleOverview (bool visible);
    void addBackgroundProcessToStatusBar (QString name, int max);
    void updateBackgroundProcessonStatusBar (QString name, int value);
    void removeBackgroundProcessFromStatusBar (QString name);

private:
    QAction* action (QString const& action_id);

    MainWindow(const MainWindow&);
    const MainWindow& operator=(const MainWindow&);

    void initActions();
    void initToolBars();
    void initMenus (QSharedPointer<ApplicationContext> application_context);
    void initHamburgerMenu();
    void initStatusBar();

    QMenu* file_menu_;
    QMenu* file_recent_files_menu_;
    QMenu* edit_menu_;
    QMenu* mouse_mode_menu_;
    QMenu* view_menu_;
    QMenu* tools_menu_;
    QMenu* help_menu_;

    QToolBar* file_toolbar_;

    QLabel* status_bar_signal_length_label_;
    QLabel* status_bar_nr_channels_label_;

    QAction* overview_action_;
    QAction* toggle_menubar_;
    QAction* hamburger_spacer_action_;
    QAction* hamburger_action_;
    QToolButton* hamburger_button_;
    QMap<QString, QProgressBar*> background_processes_progressbars_;
    QMap<QString, QLabel*> background_processes_labels_;
};

}

#endif

